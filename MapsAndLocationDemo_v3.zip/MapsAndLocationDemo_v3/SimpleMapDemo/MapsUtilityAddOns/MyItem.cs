using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MapsAndLocationDemo.MapsUtilityAddOns;
using Android.Gms.Maps.Model;
using Android.Gms.Maps.Utils.Clustering;

namespace SimpleMapDemo.MapsUtilityAddOns
{
    public class MyItem : Java.Lang.Object, IClusterItem
    {
        private LatLng position;

        public MyItem(double lat, double lng)
        {
            position = new LatLng(lat, lng);
        }

        public LatLng Position
        {
            get { return position; }
            set
            {
                position = value;
             }
        }

      
    }


}