using System.Collections.Generic;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Gms.Maps.Utils.Clustering;

namespace MapsAndLocationDemo.MapsUtilityAddOns
{
  // com.google.android.gms.maps.model
   
	/// <summary>
	/// A collection of ClusterItems that are nearby each other.
	/// </summary>
	public interface Cluster<T> where T : IClusterItem
	{
		LatLng Position {get;}

		ICollection<T> Items {get;}

		int Size {get;}
	}
}