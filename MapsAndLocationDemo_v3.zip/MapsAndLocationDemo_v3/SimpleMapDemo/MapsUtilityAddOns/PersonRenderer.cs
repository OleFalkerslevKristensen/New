using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Gms.Maps.Utils.Clustering.View;
using Android.Gms.Maps.Utils.UI;
using Android.Gms.Maps.Model;
using Android.Graphics;

namespace SimpleMapDemo.MapsUtilityAddOns
{
    public class PersonRenderer /*: DefaultClusterRenderer*/
    {

        Android.Content.Context _context;
 //       internal readonly IconGenerator mIconGenerator = new IconGenerator(ApplicationContext);
 //       internal readonly IconGenerator mClusterIconGenerator = new IconGenerator(ApplicationContext);
        ImageView mImageView;
        ImageView mClusterImageView;
        int mDimension;

        public PersonRenderer(Android.Content.Context context)
        {
             _context = context;
             IconGenerator mIconGenerator = new IconGenerator(_context);
             IconGenerator mClusterIconGenerator = new IconGenerator(_context);

        }

        public  void onBeforeClusterItemRendered(Ondo person, MarkerOptions markerOptions)
        {
            // Draw a single person.
            // Set the info window to show their name.
     //       mImageView.ImageResource = person.profilePhoto;
     //       Bitmap icon = mIconGenerator.makeIcon();
     //       markerOptions.Icon(BitmapDescriptorFactory.FromBitmap(icon)).title(person.name);
        }


    }
}