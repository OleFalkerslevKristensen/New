using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MapsAndLocationDemo.MapsUtilityAddOns;
using Android.Gms.Maps.Model;
using Android.Gms.Maps.Utils.Clustering;

namespace SimpleMapDemo.MapsUtilityAddOns
{
    public class Ondo : Java.Lang.Object, IClusterItem
    {
        public string name;
        public  int profilePhoto;
        private  LatLng mPosition;
        private string mSnippet;
   
        public Ondo(LatLng position, string name, int pictureResource, string snippet)
        {
            this.name = name;
            profilePhoto = pictureResource;
            mPosition = position;
            mSnippet = snippet;
        }

        public  LatLng Position
        {
            get
            {
                return mPosition;
            }
        }

        public int ProfilePhoto
        {
            get
            {
                return profilePhoto;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
        }

        public string Snippet
        {
            get
            {
                return mSnippet;
            }
        }

      
    }
}