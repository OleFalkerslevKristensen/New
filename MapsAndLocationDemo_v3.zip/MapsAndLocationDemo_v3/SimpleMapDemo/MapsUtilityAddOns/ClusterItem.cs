using Android.Gms.Maps.Model;
//using Android.Gms.Maps




namespace MapsAndLocationDemo.MapsUtilityAddOns
{
 
	/// <summary>
	/// ClusterItem represents a marker on the map.
	/// </summary>
//    public interface IClusterItem
 //   {
 //       LatLng Position { get; set; }
/*
        public ClusterItem(double lat, double lng)
        {
            Position = new LatLng(lat, lng);
        }



    }  */

   
}