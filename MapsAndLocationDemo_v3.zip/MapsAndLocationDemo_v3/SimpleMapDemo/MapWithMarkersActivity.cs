namespace SimpleMapDemo
{
    using System;

    using Android.App;
    using Android.Gms.Maps;
    using Android.Gms.Maps.Model;
    using Android.OS;
    using Android.Widget;

  //  using Com.Google.Maps.Android.Clustering;
    using SimpleMapDemo.MapsUtilityAddOns;
    using MapsAndLocationDemo.MapsUtilityAddOns;
    using System.Collections.Generic;
    using Android.Gms.Maps.Utils.Clustering;
    using Android.Gms.Maps.Utils.UI;
    using System.Collections;
    using Android.Views;
    using Android.Gms.Maps.Utils.Clustering.View;
    using Android.Graphics;
    using Android.Content;

    

    [Activity(Label = "@string/activity_label_mapwithmarkers")]
    public class MapWithMarkersActivity : Activity, ClusterManager.IOnClusterClickListener, ClusterManager.IOnClusterItemClickListener,
  
     /*  ClusterManager.IOnClusterInfoWindowClickListener*/ClusterManager.IOnClusterItemInfoWindowClickListener
    {

 //       public static Hashtable mapTags = new Hashtable();
        public static Dictionary<Ondo, string> mapTags = new Dictionary<Ondo, string>();

        private static readonly LatLng InMaui = new LatLng(51.5, 0);  //(20.72110, -156.44776);       
        private static readonly LatLng LeaveFromHereToMaui = new LatLng(82.4986, -62.348);
        private static readonly LatLng[] LocationForCustomIconMarkers = new[]
                                                                            {
                                                                                new LatLng(40.741773, -74.004986),
                                                                                new LatLng(41.051696, -73.545667),
                                                                                new LatLng(41.311197, -72.902646)
                                                                            };
        private string _gotoMauiMarkerId;
        private GoogleMap _map;
        private MapFragment _mapFragment;
 //       private Marker _polarBearMarker;
 //       private GroundOverlay _polarBearOverlay;

        ClusterManager mClusterManager;


        private Random mRandom = new Random(1984);

        private float zoomLevel = 7;

  


        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.MapWithOverlayLayout);
            InitMapFragment();
            SetupMapIfNeeded();
        }

        protected override void OnPause()
        {
            base.OnPause();

            // Pause the GPS - we won't have to worry about showing the 
            // location.
            _map.MyLocationEnabled = false;

            _map.MarkerClick -= MapOnMarkerClick;
        }

        protected override void OnResume()
        {
            base.OnResume();
            SetupMapIfNeeded();

            _map.MyLocationEnabled = true;

            // Setup a handler for when the user clicks on a marker.
            _map.MarkerClick += MapOnMarkerClick;

            mClusterManager = new ClusterManager(this, _map);

            mClusterManager.SetOnClusterClickListener(this);
            mClusterManager.SetOnClusterItemClickListener(this);
            _map.SetOnCameraChangeListener(mClusterManager);
            _map.SetOnMarkerClickListener(mClusterManager);

      //          _map.SetOnCameraChangeListener(this);  gives problem

            mClusterManager.SetRenderer(new PersonRenderer(Application.Context, _map, mClusterManager));
      //      mClusterManager.SetRenderer(new PersonRenderer(this));

              
            for (int i = 0; i < 30; i++)
            {
                AddClusterItems(i);
            }

   
             _map.SetOnInfoWindowClickListener(mClusterManager);
      //       mClusterManager.SetOnClusterInfoWindowClickListener(this);
             mClusterManager.SetOnClusterItemInfoWindowClickListener(this);

          
             mClusterManager.Cluster();
            


        }

#if _ACTIVE__
        private void AddInitialPolarBarToMap()
        {
            MarkerOptions markerOptions = new MarkerOptions()
                .SetSnippet("Click me to go on vacation.")
                .SetPosition(LeaveFromHereToMaui)
                .SetTitle("Goto Maui");
            _polarBearMarker = _map.AddMarker(markerOptions);
            _polarBearMarker.ShowInfoWindow();

            _gotoMauiMarkerId = _polarBearMarker.Id;

            PositionPolarBearGroundOverlay(LeaveFromHereToMaui);
        }

        /// <summary>
        ///   Add three markers to the map.
        /// </summary>
        private void AddMonkeyMarkersToMap()
        {
            for (int i = 0; i < LocationForCustomIconMarkers.Length; i++)
            {
                BitmapDescriptor icon = BitmapDescriptorFactory.FromResource(Resource.Drawable.monkey);
                MarkerOptions mapOption = new MarkerOptions()
                    .SetPosition(LocationForCustomIconMarkers[i])
                    .InvokeIcon(icon)
                    .SetSnippet(String.Format("This is marker #{0}.", i))
                    .SetTitle(String.Format("Marker {0}", i));
                _map.AddMarker(mapOption);
            }
        }
#endif
        private void InitMapFragment()
        {
            _mapFragment = FragmentManager.FindFragmentByTag("map") as MapFragment;
            if (_mapFragment == null)
            {
                GoogleMapOptions mapOptions = new GoogleMapOptions()
                    .InvokeMapType(GoogleMap.MapTypeSatellite)
 //                   .InvokeZoomControlsEnabled(false)
                    .InvokeZoomControlsEnabled(true)
                    .InvokeCompassEnabled(true);

                FragmentTransaction fragTx = FragmentManager.BeginTransaction();
                _mapFragment = MapFragment.NewInstance(mapOptions);
                fragTx.Add(Resource.Id.mapWithOverlay, _mapFragment, "map");
                fragTx.Commit();
            }
        }

        private void MapOnMarkerClick(object sender, GoogleMap.MarkerClickEventArgs markerClickEventArgs)
        {
            Marker marker = markerClickEventArgs.P0; // TODO [TO201212142221] Need to fix the name of this with MetaData.xml
            if (marker.Id.Equals(_gotoMauiMarkerId))
            {
  //              PositionPolarBearGroundOverlay(InMaui);
                _map.AnimateCamera(CameraUpdateFactory.NewLatLngZoom(InMaui, 13));
                _gotoMauiMarkerId = null;
     //           _polarBearMarker.Remove();
    //            _polarBearMarker = null;
            }
            else
            {
                Toast.MakeText(this, String.Format("You clicked on Marker ID {0}", marker.Id), ToastLength.Short).Show();
            }
        }
/*
        private void PositionPolarBearGroundOverlay(LatLng position)
        {
            if (_polarBearOverlay == null)
            {
                BitmapDescriptor image = BitmapDescriptorFactory.FromResource(Resource.Drawable.polarbear);
                GroundOverlayOptions groundOverlayOptions = new GroundOverlayOptions()
                    .Position(position, 150, 200)
                    .InvokeImage(image);
                _polarBearOverlay = _map.AddGroundOverlay(groundOverlayOptions);
            }
            else
            {
                _polarBearOverlay.Position = InMaui;
            }
        }
*/
        public void SetViewPoint(LatLng latlng, bool animated)
        {
            CameraPosition.Builder builder = CameraPosition.InvokeBuilder();
            builder.Target(latlng);
            builder.Zoom(14.5F);

  
            CameraPosition cameraPosition = builder.Build();

            if (animated)
            {
                _map.AnimateCamera(CameraUpdateFactory.NewCameraPosition(cameraPosition));
            }
            else
            {
                _map.MoveCamera(CameraUpdateFactory.NewCameraPosition(cameraPosition));
            }
        }

        private void SetupMapIfNeeded()
        {
            if (_map == null)
            {
                _map = _mapFragment.Map;
                if (_map != null)
                {
      //              AddMonkeyMarkersToMap();
      //              AddInitialPolarBarToMap();

     //               SetViewPoint(new LatLng(55.430515, 12.395053), false);
                    SetViewPoint(new LatLng(51.6723432, 51.38494009999999), false);
   
                  
                    // Move the map so that it is showing the markers we added above.
                    //              _map.AnimateCamera(CameraUpdateFactory.NewLatLngZoom(LocationForCustomIconMarkers[1], 2));   

                    _map.AnimateCamera(CameraUpdateFactory.NewLatLngZoom(InMaui, zoomLevel));

                     
                }
            }
        }

/*        

        private void AddClusterItems()
        {
            double lat = 55.430515;
            double lng = 12.395053;

            List<MyItem> items = new List<MyItem>();

            for (var i = 0; i < 100; i++)
            {
                double offset = i / 500d;
                lat = lat + offset;
                lng = lng + offset;

                var item = new MyItem(lat, lng);
                items.Add(item);
            }

            try
            {

                mClusterManager.AddItems(items);

            }

            catch (Exception exc)
            {
                string t = exc.Message;
            }
        }
*/
        private void AddClusterItems(int i)
        {
            // http://www.flickr.com/photos/sdasmarchives/5036248203/
          
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 1", Resource.Drawable.p01001, "snippet 1"));
  
            // http://www.flickr.com/photos/usnationalarchives/4726917149/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 2", Resource.Drawable.p01002, "snippet 2"));

            // http://www.flickr.com/photos/nypl/3111525394/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 3", Resource.Drawable.p01003, "snippet 3"));

            // http://www.flickr.com/photos/smithsonian/2887433330/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 4", Resource.Drawable.p01004, "snippet 4"));

            // http://www.flickr.com/photos/library_of_congress/2179915182/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 5", Resource.Drawable.p01005, "snippet 5"));

            // http://www.flickr.com/photos/nationalmediamuseum/7893552556/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 6", Resource.Drawable.p01006, "snippet 6"));

            // http://www.flickr.com/photos/sdasmarchives/5036231225/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 7", Resource.Drawable.p01007, "snippet 7"));

            // http://www.flickr.com/photos/anmm_thecommons/7694202096/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 8", Resource.Drawable.p01008, "snippet 8"));

            // http://www.flickr.com/photos/usnationalarchives/4726892651/
           mClusterManager.AddItem(new Ondo(position(), "Adam butik 9", Resource.Drawable.p01009, "snippet 9"));

        }


        private LatLng position()
        {
            return new LatLng(random(51.6723432, 51.38494009999999), random(0.148271, -0.3514683));
        }

        private double random(double min, double max)
        {
            return mRandom.NextDouble() * (max - min) + min;
        }



        //Cluster override methods
        public bool OnClusterClick(ICluster cluster)
        {
            Toast.MakeText(this, cluster.Items.Count + " items in cluster", ToastLength.Short).Show();
            return false;
        }

        public bool OnClusterItemClick(Java.Lang.Object marker)
        {
            Ondo m = marker as Ondo;

            Toast.MakeText(this, m.name, ToastLength.Short).Show();
            return false;
        }

        public void OnClusterItemInfoWindowClick(Java.Lang.Object ondo)
        {

            Ondo o = ondo as Ondo;

            string snippet = (string)MapWithMarkersActivity.mapTags[o];
            Toast.MakeText(this, snippet, ToastLength.Short).Show();

        }

        public void OnCameraChange(CameraPosition position)
        {
     
        }


#if __ACTIVE__   
    public void OnClusterInfoWindowClick(Cluster<Person> cluster) {
        // Does nothing, but you could go to a list of the users.
    }

    public void OnClusterChanged(Cluster<Person> cluster)
    {
        // Does nothing, but you could go to a list of the users.
    }
   
    public bool OnClusterItemClick(Person item) {
        // Does nothing, but you could go into the user's profile page, for example.
        return false;
    }


    public void OnClusterItemInfoWindowClickListener(Java.Lang.Object item)
    {
        // Does nothing, but you could go into the user's profile page, for example.
    }
#endif




    }

    public class PersonRenderer : DefaultClusterRenderer//, IClusterRenderer
    {
        private Context ctx;
        
        private IconGenerator mIconGenerator = new IconGenerator(Application.Context);
        private IconGenerator mClusterIconGenerator = new IconGenerator(Application.Context);
        private ImageView mImageView;
        private ImageView mClusterImageView;


        public PersonRenderer(Android.Content.Context ctx, GoogleMap map, ClusterManager clusterMgr)
            : base(/*ctx*/Application.Context, map, clusterMgr) 
        {
            mImageView = new ImageView(Application.Context);
         
        }

        protected override bool ShouldRenderAsCluster(ICluster cluster)
        {
            // Always render clusters.
            return cluster.Size > 1;
        }

        protected override void OnClusterItemRendered(Java.Lang.Object ondo, Marker marker)
        {
            Ondo o = ondo as Ondo;

      
        }
 
        protected override void OnBeforeClusterItemRendered(Java.Lang.Object ondo, MarkerOptions markerOptions)
        {
            Ondo o = ondo as Ondo;
            
            BitmapDescriptor icon; icon = BitmapDescriptorFactory.FromResource(o.profilePhoto);
            markerOptions.InvokeIcon(icon).SetTitle(o.name +  "    <50km");
    //        markerOptions.SetSnippet(o.Snippet);

            try
            {
    //           MapWithMarkersActivity.mapTags.Add(o, o.Snippet);
                if (!MapWithMarkersActivity.mapTags.ContainsKey(o))
                {
                    MapWithMarkersActivity.mapTags[o] = o.Snippet;
                }
      
            }
            catch (Exception ex)
            {
                Console.WriteLine("******EXCEPTION*****"+ ex.Message);
            }
		}

    }
}
