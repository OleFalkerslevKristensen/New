namespace SimpleMapDemo
{
    using Android.App;
    using Android.Gms.Maps;
    using Android.Gms.Maps.Model;
    using Android.OS;
    using SimpleMapDemo.MapsUtilityAddOns;

 
    using Android.Gms.Maps.Utils.Clustering;
    using MapsAndLocationDemo.MapsUtilityAddOns;

    [Activity(Label = "@string/basic_map")]
    public class BasicDemoActivity : Activity
    {

        private GoogleMap _map;
        private MapFragment _mapFragment;

   //     abstract public class ClusterManager<T> : GoogleMap.IOnCameraChangeListener, GoogleMap.IOnMarkerClickListener, GoogleMap.IOnInfoWindowClickListener where T : ClusterItem { }
  //      private ClusterManager<MyItem> mClusterManager;
  
        
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

   //         SetContentView(Resource.Layout.BasicDemo);

            SetContentView(Resource.Layout.MapWithOverlayLayout);
            InitMapFragment();
            SetupMapIfNeeded();
        }

        protected override void OnPause()
        {
            base.OnPause();

            // Pause the GPS - we won't have to worry about showing the 
            // location.
            _map.MyLocationEnabled = false;

   //         _map.MarkerClick -= MapOnMarkerClick;
        }

        protected override void OnResume()
        {
            base.OnResume();
            SetupMapIfNeeded();

            _map.MyLocationEnabled = true;

            _map.AnimateCamera(CameraUpdateFactory.NewLatLngZoom(new LatLng(51.503186, -0.126446), 13));

            ClusterManager mClusterManager = new ClusterManager(this, _map);

            _map.SetOnCameraChangeListener(mClusterManager);


            // Setup a handler for when the user clicks on a marker.
 //           _map.MarkerClick += MapOnMarkerClick;
        }

        private void InitMapFragment()
        {
            _mapFragment = FragmentManager.FindFragmentByTag("map") as MapFragment;
            if (_mapFragment == null)
            {
                GoogleMapOptions mapOptions = new GoogleMapOptions()
                    .InvokeMapType(GoogleMap.MapTypeSatellite)
                    .InvokeZoomControlsEnabled(false)
                    .InvokeCompassEnabled(true);

                FragmentTransaction fragTx = FragmentManager.BeginTransaction();
                _mapFragment = MapFragment.NewInstance(mapOptions);
                fragTx.Add(Resource.Id.mapWithOverlay, _mapFragment, "map");
                fragTx.Commit();
            }
        }

        private void SetupMapIfNeeded()
        {
            if (_map == null)
            {
                _map = _mapFragment.Map;
                if (_map != null)
                {
    //                AddMonkeyMarkersToMap();
    //                AddInitialPolarBarToMap();

                    // Move the map so that it is showing the markers we added above.
    //                _map.AnimateCamera(CameraUpdateFactory.NewLatLngZoom(LocationForCustomIconMarkers[1], 2));
                }
            }
        }
    }
}
